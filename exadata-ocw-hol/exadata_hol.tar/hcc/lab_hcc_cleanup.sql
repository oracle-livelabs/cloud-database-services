SET ECHO ON

DROP TABLE mycust_archive PURGE;
DROP TABLE mycust_query PURGE;